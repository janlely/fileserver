#ifndef _ERRORCODE_H
#define _ERRORCODE_H

/*error codes*/
#define RESPONSE_OK 600
#define INVALID_PARAM 660
#define IMAGE_COMPRESS_ERROR 630

#endif
